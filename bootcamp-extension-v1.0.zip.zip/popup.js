document.getElementById("meuBotao").addEventListener("click", () => {
  alert("Parabéns! Você clicou no botão!");
});
